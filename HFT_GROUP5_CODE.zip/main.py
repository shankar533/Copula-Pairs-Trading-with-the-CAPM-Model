#region imports
from AlgorithmImports import *

from universe import Dow30UniverseSelection
from alpha import CopulaPairsTradingAlphaModel
from alpha import CAPMAlphaRankingModel

#endregion


class MultipleStrategy(QCAlgorithm):

    undesired_symbols_from_previous_deployment = []
    checked_symbols_from_previous_deployment = False
    previous_expiry_time = None
    
    def Initialize(self):        
        self.SetStartDate(2022, 1, 1)
        #self.SetEndDate(2024, 3, 4)
        self.SetCash(1_000_000)

        self.Settings.MinimumOrderMarginPortfolioPercentage = 0
        
        self.SetBrokerageModel(BrokerageName.InteractiveBrokersBrokerage, AccountType.Margin)

        lookback_days = self.GetParameter("lookback_days", 250) # length of history data in trading period
        lookback = self.GetParameter("lookback", 21)

        self.UniverseSettings.DataNormalizationMode = DataNormalizationMode.Raw
        # Select optimal trading pair into the universe
        tickers = ["XLE", "VDE", "USO", "AMLP", "XOP", "GOVT", "META", "AAPL", "AMZN", "NFLX", "GOOGL", "NVDA", "MSFT"]
        symbols = [ Symbol.Create(ticker, SecurityType.Equity, Market.USA) for ticker in tickers]

        dia = self.AddEquity("DIA",
            resolution = self.UniverseSettings.Resolution,
            dataNormalizationMode = self.UniverseSettings.DataNormalizationMode).Symbol
        self.SetBenchmark(dia)
        
        self.AddUniverseSelection(ManualUniverseSelectionModel(symbols))
        self.AddUniverseSelection(Dow30UniverseSelection(dia, self.UniverseSettings))

        self.UniverseSettings.DataNormalizationMode = DataNormalizationMode.Raw


        self.AddAlpha(CopulaPairsTradingAlphaModel(
            lookback_days,
            self.GetParameter("num_days", 1_000),
            self.GetParameter("cap_CL", 0.95),
            self.GetParameter("floor_CL", 0.05),
            self.GetParameter("weight_v", 0.5)
        ))
        self.AddAlpha(CAPMAlphaRankingModel(dia, lookback))

  


        self.Settings.RebalancePortfolioOnSecurityChanges = False
        self.Settings.RebalancePortfolioOnInsightChanges = False
        #self.SetPortfolioConstruction(InsightWeightingPortfolioConstructionModel(self.rebalance_func))
        #self.SetPortfolioConstruction(EqualWeightingPortfolioConstructionModel(Expiry.EndOfWeek))
        self.SetPortfolioConstruction(EqualWeightingPortfolioConstructionModel(self.rebalance_func))

        self.AddRiskManagement(NullRiskManagementModel())
        
        self.SetExecution(ImmediateExecutionModel())

        self.SetWarmUp(timedelta(90))

    def rebalance_func(self, time):
        # Rebalance when all of the following are true:
        # - There are new insights or old insights have been cancelled
        # - The algorithm isn't warming up
        # - There is QuoteBar data in the current slice
        latest_expiry_time = sorted([insight.CloseTimeUtc for insight in self.Insights], reverse=True)[0] if self.Insights.Count else None
        if self.previous_expiry_time != latest_expiry_time and not self.IsWarmingUp and self.CurrentSlice.QuoteBars.Count > 0:
            self.previous_expiry_time = latest_expiry_time
            return time
        return None

    def OnData(self, data):
        # Exit positions that aren't backed by existing insights.
        # If you don't want this behavior, delete this method definition.
        if not self.IsWarmingUp and not self.checked_symbols_from_previous_deployment:
            for security_holding in self.Portfolio.Values:
                if not security_holding.Invested:
                    continue
                symbol = security_holding.Symbol
                if not self.Insights.HasActiveInsights(symbol, self.UtcTime):
                    self.undesired_symbols_from_previous_deployment.append(symbol)
            self.checked_symbols_from_previous_deployment = True
        
        for symbol in self.undesired_symbols_from_previous_deployment[:]:
            if self.IsMarketOpen(symbol):
                self.Liquidate(symbol, tag="Holding from previous deployment that's no longer desired")
                self.undesired_symbols_from_previous_deployment.remove(symbol)