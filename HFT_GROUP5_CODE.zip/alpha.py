#region imports
from AlgorithmImports import *

from collections import deque
from statsmodels.distributions.empirical_distribution import ECDF
from scipy.stats import kendalltau
from scipy.optimize import minimize
from scipy.integrate import quad
from scipy import stats
import sys

#endregion


class CAPMAlphaRankingModel(AlphaModel):

    def __init__(self, benchmark, lookback):
        self.benchmark = benchmark
        self.lookback = lookback
        self.symbols = []
        self.month = -1

    def Update(self, algorithm, data):
        if algorithm.Time.month == self.month: return []
        self.month = algorithm.Time.month

        # Fetch the historical data and calculate the returns
        # to perform the linear regression
        returns = algorithm.History(
            self.symbols + [self.benchmark], 
            self.lookback,
            Resolution.Daily).close.unstack(level=0).pct_change().iloc[1:].fillna(0)
            
        return [
            Insight.Price(symbol, Expiry.EndOfMonth, InsightDirection.Up) for symbol in self.SelectSymbols(algorithm, returns)
        ]

    def SelectSymbols(self, algorithm, all_returns):
        '''Select symbols with the highest intercept/alpha to the benchmark
        '''
        alphas = dict()

        # Get the benchmark returns
        benchmark = all_returns[self.benchmark]

        # Conducts linear regression for each symbol and save the intercept/alpha
        for symbol in self.symbols:
            if not str(symbol.ID) in all_returns.columns:
                algorithm.Log(f'{symbol} not found in the historical data request')
                continue
            
            # Get the security returns
            returns = all_returns[symbol]
            bla = np.vstack([benchmark, np.ones(len(returns))]).T

            # Simple linear regression function in Numpy
            result = np.linalg.lstsq(bla , returns)
            alphas[symbol] = result[0][1]

        # Select symbols with the highest intercept/alpha to the benchmark
        selected = sorted(alphas.items(), key=lambda x: x[1], reverse=True)[:2]
        return [x[0] for x in selected]

    def OnSecuritiesChanged(self, algorithm, changes):
        for added in changes.AddedSecurities:
            self.symbols.append(added.Symbol)

        for removed in changes.RemovedSecurities:
            symbol = removed.Symbol
            if symbol in self.symbols:
                self.symbols.remove(symbol)



class CopulaPairsTradingAlphaModel(AlphaModel):

    window = {} # stores historical price used to calculate trading day's stock return
    coef = 0    # to be calculated: requested ratio of quantity_u / quantity_v
    day = 0     # keep track of current day for daily rebalance
    month = 0   # keep track of current month for monthly recalculation of optimal trading pair
    pair = []   # stores the selected trading pair
    duration = timedelta(90)

    def __init__(self, lookback_days, num_days, cap_CL, floor_CL, weight_v):
        self.lookback_days = lookback_days   # length of history data in trading period
        self.num_days = num_days             # length of formation period which determine the copula we use
        self.cap_CL = cap_CL                 # cap confidence level
        self.floor_CL = floor_CL             # floor confidence level
        self.weight_v = weight_v             # desired holding weight of asset v in the portfolio, adjusted to avoid insufficient buying power


    def Update(self, algorithm: QCAlgorithm, slice: Slice) -> List[Insight]:
        insights = []

        self.SetSignal(algorithm, slice)     # only executed at first day of each month

        # Daily rebalance
        if algorithm.Time.day == self.day or slice.QuoteBars.Count == 0:
            return []
        
        long, short = self.pair[0], self.pair[1]

        if len(self.window[long]) < 2 or len(self.window[short]) < 2:
            return []
        
        # Compute the mispricing indices for u and v by using estimated copula
        MI_u_v, MI_v_u = self._misprice_index()

        # Placing orders: if long is relatively underpriced, buy the pair
        if MI_u_v < self.floor_CL and MI_v_u > self.cap_CL:
            
            insights.extend([
                Insight.Price(short, self.duration, InsightDirection.Down, weight=self.weight_v),
                Insight.Price(long, self.duration, InsightDirection.Up, weight=self.weight_v * self.coef * algorithm.Portfolio[long].Price / algorithm.Portfolio[short].Price),
            ])

        # Placing orders: if short is relatively underpriced, sell the pair
        elif MI_u_v > self.cap_CL and MI_v_u < self.floor_CL:

            insights.extend([
                Insight.Price(short, self.duration, InsightDirection.Up, weight=self.weight_v),
                Insight.Price(long, self.duration, InsightDirection.Down, weight=self.weight_v * self.coef * algorithm.Portfolio[long].Price / algorithm.Portfolio[short].Price),
            ])
        
        self.day = algorithm.Time.day
        return insights


    def SetSignal(self, algorithm, slice):
        '''Computes the mispricing indices to generate the trading signals.
        It's called on first day of each month'''

        if algorithm.Time.month == self.month:
            return
        
        ## Compute the best copula
        
        # Pull historical log returns used to determine copula
        history = algorithm.History(self.pair, self.num_days, Resolution.Daily, dataNormalizationMode=DataNormalizationMode.ScaledRaw)
        if history.empty:
            return
        history = history.close.unstack(level=0)
        logreturns = (np.log(history) - np.log(history.shift(1))).dropna()

        x, y = logreturns[str(self.pair[0])], logreturns[str(self.pair[1])]

        # Convert the two returns series to two uniform values u and v using the empirical distribution functions
        ecdf_x, ecdf_y  = ECDF(x), ECDF(y)
        u, v = [ecdf_x(a) for a in x], [ecdf_y(a) for a in y]
        
        # Compute the Akaike Information Criterion (AIC) for different copulas and choose copula with minimum AIC
        tau = kendalltau(x, y)[0]  # estimate Kendall'rank correlation
        AIC ={}  # generate a dict with key being the copula family, value = [theta, AIC]
        
        for i in ['clayton', 'frank', 'gumbel']:
            param = self._parameter(i, tau)
            lpdf = [self._lpdf_copula(i, param, x, y) for (x, y) in zip(u, v)]
            # Replace nan with zero and inf with finite numbers in lpdf list
            lpdf = np.nan_to_num(lpdf) 
            loglikelihood = sum(lpdf)
            AIC[i] = [param, -2 * loglikelihood + 2]
            
        # Choose the copula with the minimum AIC
        self.copula = min(AIC.items(), key = lambda x: x[1][1])[0]
        
        ## Compute the signals
        
        # Generate the log return series of the selected trading pair
        logreturns = logreturns.tail(self.lookback_days)
        x, y = logreturns[str(self.pair[0])], logreturns[str(self.pair[1])]
        
        # Estimate Kendall'rank correlation
        tau = kendalltau(x, y)[0] 
        
        # Estimate the copula parameter: theta
        self.theta = self._parameter(self.copula, tau)
        
        # Simulate the empirical distribution function for returns of selected trading pair
        self.ecdf_x, self.ecdf_y  = ECDF(x), ECDF(y) 
        
        # Run linear regression over the two history return series and return the desired trading size ratio
        self.coef = stats.linregress(x,y).slope
        
        self.month = algorithm.Time.month
        
        
    def _parameter(self, family, tau):
        ''' Estimate the parameters for three kinds of Archimedean copulas
        according to association between Archimedean copulas and the Kendall rank correlation measure
        '''
        
        if  family == 'clayton':
            return 2 * tau / (1 - tau)
        
        elif family == 'frank':
            
            '''
            debye = quad(integrand, sys.float_info.epsilon, theta)[0]/theta  is first order Debye function
            frank_fun is the squared difference
            Minimize the frank_fun would give the parameter theta for the frank copula 
            ''' 
            
            integrand = lambda t: t / (np.exp(t) - 1)  # generate the integrand
            frank_fun = lambda theta: ((tau - 1) / 4.0  - (quad(integrand, sys.float_info.epsilon, theta)[0] / theta - 1) / theta) ** 2
            
            return minimize(frank_fun, 4, method='BFGS', tol=1e-5).x 
        
        elif family == 'gumbel':
            return 1 / (1 - tau)
            

    def _lpdf_copula(self, family, theta, u, v):
        '''Estimate the log probability density function of three kinds of Archimedean copulas
        '''
        
        if  family == 'clayton':
            pdf = (theta + 1) * ((u * (-theta) + v * (-theta) - 1) * (-2 - 1 / theta)) * (u * (-theta - 1) * v ** (-theta - 1))
            
        elif family == 'frank':
            num = -theta * (np.exp(-theta) - 1) * (np.exp(-theta * (u + v)))
            denom = ((np.exp(-theta * u) - 1) * (np.exp(-theta * v) - 1) + (np.exp(-theta) - 1)) ** 2
            pdf = num / denom
            
        elif family == 'gumbel':
            A = (-np.log(u)) * theta + (-np.log(v)) * theta
            c = np.exp(-A ** (1 / theta))
            pdf = c * (u * v) * (-1) * (A * (-2 + 2 / theta)) * ((np.log(u) * np.log(v)) * (theta - 1)) * (1 + (theta - 1) * A * (-1 / theta))
            
        return np.log(pdf)


    def _misprice_index(self):
        '''Calculate mispricing index for every day in the trading period by using estimated copula
        Mispricing indices are the conditional probability P(U < u | V = v) and P(V < v | U = u)'''        
        return_x = np.log(self.window[self.pair[0]][-1] / self.window[self.pair[0]][-2])
        return_y = np.log(self.window[self.pair[1]][-1] / self.window[self.pair[1]][-2])
        
        # Convert the two returns to uniform values u and v using the empirical distribution functions
        u = self.ecdf_x(return_x)
        v = self.ecdf_y(return_y)
        
        if self.copula == 'clayton':
            MI_u_v = v * (-self.theta - 1) * (u * (-self.theta) + v * (-self.theta) - 1) * (-1 / self.theta - 1) # P(U<u|V=v)
            MI_v_u = u * (-self.theta - 1) * (u * (-self.theta) + v * (-self.theta) - 1) * (-1 / self.theta - 1) # P(V<v|U=u)
    
        elif self.copula == 'frank':
            A = (np.exp(-self.theta * u) - 1) * (np.exp(-self.theta * v) - 1) + (np.exp(-self.theta * v) - 1)
            B = (np.exp(-self.theta * u) - 1) * (np.exp(-self.theta * v) - 1) + (np.exp(-self.theta * u) - 1)
            C = (np.exp(-self.theta * u) - 1) * (np.exp(-self.theta * v) - 1) + (np.exp(-self.theta) - 1)
            MI_u_v = B / C
            MI_v_u = A / C
        
        elif self.copula == 'gumbel':
            A = (-np.log(u)) * self.theta + (-np.log(v)) * self.theta
            C_uv = np.exp(-A ** (1 / self.theta))   # C_uv is gumbel copula function C(u,v)
            MI_u_v = C_uv * (A * ((1 - self.theta) / self.theta)) * (-np.log(v)) * (self.theta - 1) * (1.0 / v)
            MI_v_u = C_uv * (A * ((1 - self.theta) / self.theta)) * (-np.log(u)) * (self.theta - 1) * (1.0 / u)
            
        return MI_u_v, MI_v_u

    def OnSecuritiesChanged(self, algorithm: QCAlgorithm, changes: SecurityChanges) -> None:
        '''Warms up the historical price for the newly selected pair.
        It's called when current security universe changes'''
        for security in changes.RemovedSecurities:
            symbol = security.Symbol
            self.window.pop(symbol)
            if security.Invested:
                self.Liquidate(symbol, "Removed from Universe")
            algorithm.SubscriptionManager.RemoveConsolidator(security.Symbol, security.consolidator)
        
        for security in changes.AddedSecurities:
            self.window[security.Symbol] = deque(maxlen = 2)
            
            security.consolidator = TradeBarConsolidator(timedelta(1))
            security.consolidator.DataConsolidated += lambda _, consolidated_bar: self.window[consolidated_bar.Symbol].append(consolidated_bar.Close)
            algorithm.SubscriptionManager.AddConsolidator(security.Symbol, security.consolidator)
        
        self.pair = list(self.window.keys())
        
        # Warm up historical prices
        history = algorithm.History(self.pair, 2, Resolution.Daily, dataNormalizationMode=DataNormalizationMode.ScaledRaw)
        history = history.close.unstack(level=0)
        for symbol in self.window:
            for i in range(2):
                self.window[symbol].append(history[str(symbol)][i])